<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c411133a9ab9e7bc9f7c7e6cf61e991ab3c099bbed0e7b5ac63e9ceff2d20eb2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c411133a9ab9e7bc9f7c7e6cf61e991ab3c099bbed0e7b5ac63e9ceff2d20eb2->enter($__internal_c411133a9ab9e7bc9f7c7e6cf61e991ab3c099bbed0e7b5ac63e9ceff2d20eb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_b6b4d6475c99f185c2841891e7ead6f81ebfb63ea38a5fb723d79085b65b1427 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6b4d6475c99f185c2841891e7ead6f81ebfb63ea38a5fb723d79085b65b1427->enter($__internal_b6b4d6475c99f185c2841891e7ead6f81ebfb63ea38a5fb723d79085b65b1427_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_c411133a9ab9e7bc9f7c7e6cf61e991ab3c099bbed0e7b5ac63e9ceff2d20eb2->leave($__internal_c411133a9ab9e7bc9f7c7e6cf61e991ab3c099bbed0e7b5ac63e9ceff2d20eb2_prof);

        
        $__internal_b6b4d6475c99f185c2841891e7ead6f81ebfb63ea38a5fb723d79085b65b1427->leave($__internal_b6b4d6475c99f185c2841891e7ead6f81ebfb63ea38a5fb723d79085b65b1427_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_32c1a601bef5550481aabfa2433b034ff72eb5ff5f9a27681af503049381a6b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32c1a601bef5550481aabfa2433b034ff72eb5ff5f9a27681af503049381a6b6->enter($__internal_32c1a601bef5550481aabfa2433b034ff72eb5ff5f9a27681af503049381a6b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b9f373e6435e44c325a248c5f44c4e4184d7e1ad8046155f3a30fe6d4c7a61ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b9f373e6435e44c325a248c5f44c4e4184d7e1ad8046155f3a30fe6d4c7a61ff->enter($__internal_b9f373e6435e44c325a248c5f44c4e4184d7e1ad8046155f3a30fe6d4c7a61ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_b9f373e6435e44c325a248c5f44c4e4184d7e1ad8046155f3a30fe6d4c7a61ff->leave($__internal_b9f373e6435e44c325a248c5f44c4e4184d7e1ad8046155f3a30fe6d4c7a61ff_prof);

        
        $__internal_32c1a601bef5550481aabfa2433b034ff72eb5ff5f9a27681af503049381a6b6->leave($__internal_32c1a601bef5550481aabfa2433b034ff72eb5ff5f9a27681af503049381a6b6_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_057cc133dd67fdeaffff544da0ab4f1f8c432bd9e30d55467c6e1e93a657cf06 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_057cc133dd67fdeaffff544da0ab4f1f8c432bd9e30d55467c6e1e93a657cf06->enter($__internal_057cc133dd67fdeaffff544da0ab4f1f8c432bd9e30d55467c6e1e93a657cf06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_0c598dd93a70296b03969ce70fc099867dc36232dc999d233b6600b562e2e9ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c598dd93a70296b03969ce70fc099867dc36232dc999d233b6600b562e2e9ff->enter($__internal_0c598dd93a70296b03969ce70fc099867dc36232dc999d233b6600b562e2e9ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_0c598dd93a70296b03969ce70fc099867dc36232dc999d233b6600b562e2e9ff->leave($__internal_0c598dd93a70296b03969ce70fc099867dc36232dc999d233b6600b562e2e9ff_prof);

        
        $__internal_057cc133dd67fdeaffff544da0ab4f1f8c432bd9e30d55467c6e1e93a657cf06->leave($__internal_057cc133dd67fdeaffff544da0ab4f1f8c432bd9e30d55467c6e1e93a657cf06_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_78eaef5e01f5e4aeb74415a6f5b6a3cc32c55c63ba74cb1323ae5d6cef20db87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78eaef5e01f5e4aeb74415a6f5b6a3cc32c55c63ba74cb1323ae5d6cef20db87->enter($__internal_78eaef5e01f5e4aeb74415a6f5b6a3cc32c55c63ba74cb1323ae5d6cef20db87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_de30facbfe5a6e2d873237304516dd0745851ad0be3eabad49e152f4c53bab69 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de30facbfe5a6e2d873237304516dd0745851ad0be3eabad49e152f4c53bab69->enter($__internal_de30facbfe5a6e2d873237304516dd0745851ad0be3eabad49e152f4c53bab69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_de30facbfe5a6e2d873237304516dd0745851ad0be3eabad49e152f4c53bab69->leave($__internal_de30facbfe5a6e2d873237304516dd0745851ad0be3eabad49e152f4c53bab69_prof);

        
        $__internal_78eaef5e01f5e4aeb74415a6f5b6a3cc32c55c63ba74cb1323ae5d6cef20db87->leave($__internal_78eaef5e01f5e4aeb74415a6f5b6a3cc32c55c63ba74cb1323ae5d6cef20db87_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_5df4ef000d28827eb4f75c5e36814132e79aea7e3bb512f8872deab5d39bc0b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5df4ef000d28827eb4f75c5e36814132e79aea7e3bb512f8872deab5d39bc0b0->enter($__internal_5df4ef000d28827eb4f75c5e36814132e79aea7e3bb512f8872deab5d39bc0b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_1dd9ee4016ad46561acdd2840c6f3ea1642f68e654045235d3a28c95809829cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1dd9ee4016ad46561acdd2840c6f3ea1642f68e654045235d3a28c95809829cd->enter($__internal_1dd9ee4016ad46561acdd2840c6f3ea1642f68e654045235d3a28c95809829cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_1dd9ee4016ad46561acdd2840c6f3ea1642f68e654045235d3a28c95809829cd->leave($__internal_1dd9ee4016ad46561acdd2840c6f3ea1642f68e654045235d3a28c95809829cd_prof);

        
        $__internal_5df4ef000d28827eb4f75c5e36814132e79aea7e3bb512f8872deab5d39bc0b0->leave($__internal_5df4ef000d28827eb4f75c5e36814132e79aea7e3bb512f8872deab5d39bc0b0_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_dd7853654aa5b21ae472eb96586e176b3267fa2fcf18e0ccef1be48cf5df0692 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd7853654aa5b21ae472eb96586e176b3267fa2fcf18e0ccef1be48cf5df0692->enter($__internal_dd7853654aa5b21ae472eb96586e176b3267fa2fcf18e0ccef1be48cf5df0692_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_55bc3d711a0999fa4917f806274710f9d7d9a1447aa6e9bd67c3177b21a78955 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_55bc3d711a0999fa4917f806274710f9d7d9a1447aa6e9bd67c3177b21a78955->enter($__internal_55bc3d711a0999fa4917f806274710f9d7d9a1447aa6e9bd67c3177b21a78955_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_55bc3d711a0999fa4917f806274710f9d7d9a1447aa6e9bd67c3177b21a78955->leave($__internal_55bc3d711a0999fa4917f806274710f9d7d9a1447aa6e9bd67c3177b21a78955_prof);

        
        $__internal_dd7853654aa5b21ae472eb96586e176b3267fa2fcf18e0ccef1be48cf5df0692->leave($__internal_dd7853654aa5b21ae472eb96586e176b3267fa2fcf18e0ccef1be48cf5df0692_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_f4e82cd7a2e85f520c420ce7bd047e30bf49d77478177e9fb71ca74a3ef71b00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f4e82cd7a2e85f520c420ce7bd047e30bf49d77478177e9fb71ca74a3ef71b00->enter($__internal_f4e82cd7a2e85f520c420ce7bd047e30bf49d77478177e9fb71ca74a3ef71b00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_8ae1f8cc492586d903bcd1a9fa32b09d33c192d65fb16f2ad9fe6a13004c2e74 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ae1f8cc492586d903bcd1a9fa32b09d33c192d65fb16f2ad9fe6a13004c2e74->enter($__internal_8ae1f8cc492586d903bcd1a9fa32b09d33c192d65fb16f2ad9fe6a13004c2e74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_8ae1f8cc492586d903bcd1a9fa32b09d33c192d65fb16f2ad9fe6a13004c2e74->leave($__internal_8ae1f8cc492586d903bcd1a9fa32b09d33c192d65fb16f2ad9fe6a13004c2e74_prof);

        
        $__internal_f4e82cd7a2e85f520c420ce7bd047e30bf49d77478177e9fb71ca74a3ef71b00->leave($__internal_f4e82cd7a2e85f520c420ce7bd047e30bf49d77478177e9fb71ca74a3ef71b00_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_1cbc8b6f747646f552cae525b5c56e356ae2e607f6221fbc636e00ca0bcb8f71 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cbc8b6f747646f552cae525b5c56e356ae2e607f6221fbc636e00ca0bcb8f71->enter($__internal_1cbc8b6f747646f552cae525b5c56e356ae2e607f6221fbc636e00ca0bcb8f71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_18d1fa893f7baf5408b59ff277158aeb8ded5df8d4de010b25cb53ad4bdb5ef3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18d1fa893f7baf5408b59ff277158aeb8ded5df8d4de010b25cb53ad4bdb5ef3->enter($__internal_18d1fa893f7baf5408b59ff277158aeb8ded5df8d4de010b25cb53ad4bdb5ef3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_18d1fa893f7baf5408b59ff277158aeb8ded5df8d4de010b25cb53ad4bdb5ef3->leave($__internal_18d1fa893f7baf5408b59ff277158aeb8ded5df8d4de010b25cb53ad4bdb5ef3_prof);

        
        $__internal_1cbc8b6f747646f552cae525b5c56e356ae2e607f6221fbc636e00ca0bcb8f71->leave($__internal_1cbc8b6f747646f552cae525b5c56e356ae2e607f6221fbc636e00ca0bcb8f71_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_dfec307cbc4937f70d8c75ab6802713c07bf4dc4c3466cbe66f75584e9b6c8a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dfec307cbc4937f70d8c75ab6802713c07bf4dc4c3466cbe66f75584e9b6c8a4->enter($__internal_dfec307cbc4937f70d8c75ab6802713c07bf4dc4c3466cbe66f75584e9b6c8a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_7df54cbbb3eb6c5ca1af6f714842a9af356400e86d55b9a19bd2db6825ea9a51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7df54cbbb3eb6c5ca1af6f714842a9af356400e86d55b9a19bd2db6825ea9a51->enter($__internal_7df54cbbb3eb6c5ca1af6f714842a9af356400e86d55b9a19bd2db6825ea9a51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_7df54cbbb3eb6c5ca1af6f714842a9af356400e86d55b9a19bd2db6825ea9a51->leave($__internal_7df54cbbb3eb6c5ca1af6f714842a9af356400e86d55b9a19bd2db6825ea9a51_prof);

        
        $__internal_dfec307cbc4937f70d8c75ab6802713c07bf4dc4c3466cbe66f75584e9b6c8a4->leave($__internal_dfec307cbc4937f70d8c75ab6802713c07bf4dc4c3466cbe66f75584e9b6c8a4_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\php\\Calculator\\app\\Resources\\views\\base.html.twig");
    }
}
