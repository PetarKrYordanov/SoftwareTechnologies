<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_99b2a225cb70aa4a8d48984f92fa0c34ec0fea32a96ff1e63d94ed7465a2ded8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22eba214304b375cd89b3ee524dd0d172b315c22158ea062ee25777003827b47 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22eba214304b375cd89b3ee524dd0d172b315c22158ea062ee25777003827b47->enter($__internal_22eba214304b375cd89b3ee524dd0d172b315c22158ea062ee25777003827b47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_58ed24fe863cbb6a9108045e1c098e814261f27796c82e49fae9f5db7bda5ad0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_58ed24fe863cbb6a9108045e1c098e814261f27796c82e49fae9f5db7bda5ad0->enter($__internal_58ed24fe863cbb6a9108045e1c098e814261f27796c82e49fae9f5db7bda5ad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_22eba214304b375cd89b3ee524dd0d172b315c22158ea062ee25777003827b47->leave($__internal_22eba214304b375cd89b3ee524dd0d172b315c22158ea062ee25777003827b47_prof);

        
        $__internal_58ed24fe863cbb6a9108045e1c098e814261f27796c82e49fae9f5db7bda5ad0->leave($__internal_58ed24fe863cbb6a9108045e1c098e814261f27796c82e49fae9f5db7bda5ad0_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_b359a91a99591cf11d9dc2b02bacb84fee085fa2ba202fc6b07902f9341de0f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b359a91a99591cf11d9dc2b02bacb84fee085fa2ba202fc6b07902f9341de0f1->enter($__internal_b359a91a99591cf11d9dc2b02bacb84fee085fa2ba202fc6b07902f9341de0f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_c3b44a743b00cd4a3042b8ab1909ddd82360cff9e37bc7f85527e0e5c01819df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c3b44a743b00cd4a3042b8ab1909ddd82360cff9e37bc7f85527e0e5c01819df->enter($__internal_c3b44a743b00cd4a3042b8ab1909ddd82360cff9e37bc7f85527e0e5c01819df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_c3b44a743b00cd4a3042b8ab1909ddd82360cff9e37bc7f85527e0e5c01819df->leave($__internal_c3b44a743b00cd4a3042b8ab1909ddd82360cff9e37bc7f85527e0e5c01819df_prof);

        
        $__internal_b359a91a99591cf11d9dc2b02bacb84fee085fa2ba202fc6b07902f9341de0f1->leave($__internal_b359a91a99591cf11d9dc2b02bacb84fee085fa2ba202fc6b07902f9341de0f1_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_5aba4be231ecb8cb0d30154f0990804d32e43f43fc6fd273800cacaae0ae3da2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5aba4be231ecb8cb0d30154f0990804d32e43f43fc6fd273800cacaae0ae3da2->enter($__internal_5aba4be231ecb8cb0d30154f0990804d32e43f43fc6fd273800cacaae0ae3da2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_4362850c9fe05b6762a8397e054bb2852586f7685720e682f46fc650ba54939b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4362850c9fe05b6762a8397e054bb2852586f7685720e682f46fc650ba54939b->enter($__internal_4362850c9fe05b6762a8397e054bb2852586f7685720e682f46fc650ba54939b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_4362850c9fe05b6762a8397e054bb2852586f7685720e682f46fc650ba54939b->leave($__internal_4362850c9fe05b6762a8397e054bb2852586f7685720e682f46fc650ba54939b_prof);

        
        $__internal_5aba4be231ecb8cb0d30154f0990804d32e43f43fc6fd273800cacaae0ae3da2->leave($__internal_5aba4be231ecb8cb0d30154f0990804d32e43f43fc6fd273800cacaae0ae3da2_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_9c1048eec3be09889e766d2387ec573dc7f89bcda94e70e13b7d8f427d5fa3a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c1048eec3be09889e766d2387ec573dc7f89bcda94e70e13b7d8f427d5fa3a9->enter($__internal_9c1048eec3be09889e766d2387ec573dc7f89bcda94e70e13b7d8f427d5fa3a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f2bb2d1a811b9b79b073db21d5d8ba7cfa30e468028f16c9778f3d99f3841cf8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2bb2d1a811b9b79b073db21d5d8ba7cfa30e468028f16c9778f3d99f3841cf8->enter($__internal_f2bb2d1a811b9b79b073db21d5d8ba7cfa30e468028f16c9778f3d99f3841cf8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_f2bb2d1a811b9b79b073db21d5d8ba7cfa30e468028f16c9778f3d99f3841cf8->leave($__internal_f2bb2d1a811b9b79b073db21d5d8ba7cfa30e468028f16c9778f3d99f3841cf8_prof);

        
        $__internal_9c1048eec3be09889e766d2387ec573dc7f89bcda94e70e13b7d8f427d5fa3a9->leave($__internal_9c1048eec3be09889e766d2387ec573dc7f89bcda94e70e13b7d8f427d5fa3a9_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\php\\Calculator\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
