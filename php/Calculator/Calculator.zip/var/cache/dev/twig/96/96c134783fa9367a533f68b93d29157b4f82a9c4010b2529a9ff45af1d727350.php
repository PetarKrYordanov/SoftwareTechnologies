<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d496044effa4cc39ce51801babe801f9942ccc5fec27a124c696ada197249fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d3c0020fe650971b938ae823314393c037e57442a4ee132809d96d384a565bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d3c0020fe650971b938ae823314393c037e57442a4ee132809d96d384a565bc->enter($__internal_3d3c0020fe650971b938ae823314393c037e57442a4ee132809d96d384a565bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_0eaa3e01dfb8140fc533411a27a8f20f98771847c215a772ecf58c5a58c368ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0eaa3e01dfb8140fc533411a27a8f20f98771847c215a772ecf58c5a58c368ae->enter($__internal_0eaa3e01dfb8140fc533411a27a8f20f98771847c215a772ecf58c5a58c368ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3d3c0020fe650971b938ae823314393c037e57442a4ee132809d96d384a565bc->leave($__internal_3d3c0020fe650971b938ae823314393c037e57442a4ee132809d96d384a565bc_prof);

        
        $__internal_0eaa3e01dfb8140fc533411a27a8f20f98771847c215a772ecf58c5a58c368ae->leave($__internal_0eaa3e01dfb8140fc533411a27a8f20f98771847c215a772ecf58c5a58c368ae_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_9d61b2809dd27dac78e735bcc211f299bdafa8cd02b562aaa60112b52bdc8114 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d61b2809dd27dac78e735bcc211f299bdafa8cd02b562aaa60112b52bdc8114->enter($__internal_9d61b2809dd27dac78e735bcc211f299bdafa8cd02b562aaa60112b52bdc8114_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_7778de33efba43bfaf72ef3ff48d68a7d3a3e847e2e57dbe4cb989b0e1f98619 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7778de33efba43bfaf72ef3ff48d68a7d3a3e847e2e57dbe4cb989b0e1f98619->enter($__internal_7778de33efba43bfaf72ef3ff48d68a7d3a3e847e2e57dbe4cb989b0e1f98619_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_7778de33efba43bfaf72ef3ff48d68a7d3a3e847e2e57dbe4cb989b0e1f98619->leave($__internal_7778de33efba43bfaf72ef3ff48d68a7d3a3e847e2e57dbe4cb989b0e1f98619_prof);

        
        $__internal_9d61b2809dd27dac78e735bcc211f299bdafa8cd02b562aaa60112b52bdc8114->leave($__internal_9d61b2809dd27dac78e735bcc211f299bdafa8cd02b562aaa60112b52bdc8114_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_7d277a4ce6fd8298e6fa8127f83b45782337c38fbabaab4052fbe46575f6c4c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d277a4ce6fd8298e6fa8127f83b45782337c38fbabaab4052fbe46575f6c4c4->enter($__internal_7d277a4ce6fd8298e6fa8127f83b45782337c38fbabaab4052fbe46575f6c4c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_0eef42b1745f8d3d07ecfaf586d5dea4eeb78da56a657c2bf997eed908025bdd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0eef42b1745f8d3d07ecfaf586d5dea4eeb78da56a657c2bf997eed908025bdd->enter($__internal_0eef42b1745f8d3d07ecfaf586d5dea4eeb78da56a657c2bf997eed908025bdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_0eef42b1745f8d3d07ecfaf586d5dea4eeb78da56a657c2bf997eed908025bdd->leave($__internal_0eef42b1745f8d3d07ecfaf586d5dea4eeb78da56a657c2bf997eed908025bdd_prof);

        
        $__internal_7d277a4ce6fd8298e6fa8127f83b45782337c38fbabaab4052fbe46575f6c4c4->leave($__internal_7d277a4ce6fd8298e6fa8127f83b45782337c38fbabaab4052fbe46575f6c4c4_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_7ab324b83816e4b0c606fbee5de72a2c6b07a54107b7c357973c42beb3576843 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7ab324b83816e4b0c606fbee5de72a2c6b07a54107b7c357973c42beb3576843->enter($__internal_7ab324b83816e4b0c606fbee5de72a2c6b07a54107b7c357973c42beb3576843_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_330fe68d4531711c16e8fcd16915b6765e0362c30f497ab2d828f5b6a48017a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_330fe68d4531711c16e8fcd16915b6765e0362c30f497ab2d828f5b6a48017a2->enter($__internal_330fe68d4531711c16e8fcd16915b6765e0362c30f497ab2d828f5b6a48017a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_330fe68d4531711c16e8fcd16915b6765e0362c30f497ab2d828f5b6a48017a2->leave($__internal_330fe68d4531711c16e8fcd16915b6765e0362c30f497ab2d828f5b6a48017a2_prof);

        
        $__internal_7ab324b83816e4b0c606fbee5de72a2c6b07a54107b7c357973c42beb3576843->leave($__internal_7ab324b83816e4b0c606fbee5de72a2c6b07a54107b7c357973c42beb3576843_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\php\\Calculator\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
